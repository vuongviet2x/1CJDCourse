# Cài skill "onec-dev-mentor-student" cho Gemini — bản 1.10

## 1. Cài skill
- Mở gemini.google.com → Settings → Skills → tải lên file zip này (SKILL.md nằm ngay ở gốc gói).
- Cần tài khoản Google cá nhân (chưa hỗ trợ tài khoản trường/công ty), từ 18 tuổi, bật Keep Activity.
- Tên skill chỉ gồm chữ thường và dấu gạch ngang (onec = 1C) theo yêu cầu của Gemini.
- Gemini CLI: giải nén vào ~/.gemini/skills/onec-dev-mentor-student/ sao cho có .../onec-dev-mentor-student/SKILL.md.

## 2. Gắn notebook của khóa (khuyến nghị)
Giảng viên chia sẻ notebook **1C Student Hub** (NotebookLM — nay là Gemini Notebook) chứa nguyên văn tài liệu Lý thuyết và đề Thực hành của 24 bài.
1. Mở link notebook giảng viên gửi một lần để notebook xuất hiện trong tài khoản của bạn.
2. Trong cuộc trò chuyện Gemini: bấm **+** → chọn Notebook → chọn **1C Student Hub**.
3. Hỏi như bình thường. Skill dùng gói tài liệu của mình để dạy, và dùng notebook khi cần trích nguyên văn tài liệu gốc.

Nếu Gemini trả lời như không thấy notebook, cứ hỏi tiếp — skill vẫn chạy bằng tài liệu trong gói. Muốn hỏi thẳng tài liệu gốc, mở notebook trong ứng dụng Notebook.

## 3. Tự học bằng notebook
Trong notebook, chọn nguồn của một bài (ví dụ "11. Theory - vi") rồi tạo Flashcards, Quiz, Mind map hoặc Audio Overview (chọn tiếng Việt) để ôn bài.

Notebook và skill này chỉ có đề và gợi ý, không có lời giải bài thực hành.
