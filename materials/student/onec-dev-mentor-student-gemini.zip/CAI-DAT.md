# Cài skill "onec-dev-mentor-student" cho Gemini

SKILL.md nằm ngay ở gốc gói (name: onec-dev-mentor-student). Tải thẳng file zip ở phần Skill (Spark / ứng dụng Gemini).
Gemini CLI: giải nén vào ~/.gemini/skills/onec-dev-mentor-student/ sao cho có .../onec-dev-mentor-student/SKILL.md.
Tên skill chỉ gồm chữ thường và dấu gạch ngang (onec = 1C) theo yêu cầu kebab-case của Gemini.
