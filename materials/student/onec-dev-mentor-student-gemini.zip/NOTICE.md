# 1C Dev Mentor — Notice of Ownership and Terms of Use
# 1C Dev Mentor — Thông tin sở hữu và phạm vi sử dụng

**Version / Phiên bản:** 1.10-student (Student edition / Bản dành cho sinh viên) — released / phát hành 2026-10-09
**Author & maintainer / Tác giả và người duy trì:** Phạm Viết Quý (Pham Viet Quy) — quypv@1c.com.vn
**Organization / Đơn vị:** 1C Vietnam

---

## English

### Ownership

- **This skill** — its structure, the instructions in `SKILL.md`, the terminology guide, the lesson notes, and all explanations and summaries written in Vietnamese — was authored by Phạm Viết Quý for the 1C:Enterprise development training programs of 1C Vietnam.
- **Course content** — the summaries of the 24 Theory/Practice lessons and the Extensions lesson in `references/lessons/` — is based on 1C training materials. Copyright in the original materials belongs to 1C.
- **Extension code** for the Extensions lesson is extracted from the instructor's `.cfe` files (theory demos only) (repository `1CJDCourse`, branches `lesson/extensions-*`).
- **ERP_Practice code** in `references/erp-practice/` is quoted from repository `vuongviet2x/ERP_Practice` (commit `de6ec9d`), the worked configuration of the *1C:Enterprise 8.3 Practical Developer's Guide*, used with the instructor's permission for teaching.
- **Junior Course video map** in `references/video-junior-course.md` links the 49 videos of the YouTube playlist "Junior Developer Course" (1C Vietnam Academy) to the course lessons, based on the instructor's mapping table (video IDs re-read from the playlist on 2026-10-07).
- **Q&A and practice video maps** in `references/video-qa-thuc-chien.md` and `references/video-thuc-hanh.md` link 48 videos of three YouTube playlists of the 1C Vietnam training centre ("Giải đáp câu hỏi…", "Tuyển tập các bài tập thực hành…" parts 1–2) to symptoms, lessons, learner paths and Jet project topics. Video content was checked against the videos' automatic transcripts on 2026-10-07; learner paths follow the instructor's recommendations.
- **Course demo code** in `references/lessons/` is excerpted from the lecture demo configuration of the course (repository `1CJDCourse`, `lesson/NN-theory` branches) for teaching purposes.
- **Student edition:** this edition does not contain solutions to the course Practice exercises. It contains hint cards only, and the assistant is instructed to guide rather than solve. Official solutions are held by the instructors.
- **1C:Jet code** in `references/jet/` is quoted verbatim from the open-source project 1C:Jet (github.com/1Ci-Company/Jet, branch `community`, commit `80884de`), Copyright (c) 2025 1Ci (1C International), released under the MIT License. The full license text is in `LICENSE-Jet-MIT.txt`. The MIT License applies only to the quoted Jet code, not to the rest of this skill.
- **Development standards** summarized in `references/code-review/chuan-phat-trien.md` are the author's Vietnamese summaries of the 1C:Enterprise Development Standards, via the open edition v8std.ru (github.com/zeegin/v8std, CC0 1.0). Original standards © 1C.
- **SSL API names and signatures** in `references/code-review/ssl-api-en.md` are taken from the Standard Subsystems Library 3.1 World edition (mirror github.com/1c-syntax/ssl_3_1_eng, labelled CC BY 4.0). The Standard Subsystems Library is a product of 1C; only names and signatures are quoted.
- **Static-analysis rule names** cited in `references/code-review/` come from BSL Language Server (github.com/1c-syntax/bsl-language-server, LGPL-3.0) and 1C:Code style V8 (github.com/1C-Company/v8-code-style, EPL-2.0); only rule names are cited, no code is included.
- **External source catalog** in `references/code-review/nguon-ngoai.md` lists third-party repositories by link only; their code is not included in this skill.
- **Business case material** in `references/erp-cases/` is distilled from internal survey templates and solution documents of 1C Vietnam. All customer names, figures and identifying details have been removed and replaced with aliases; no original customer file is included.

### Terms of use

- **Permitted:** students, trainees and Intern Developers enrolled in 1C Vietnam training programs may use this skill for study and course projects.
- **Not permitted without written consent from 1C Vietnam:** republishing, selling, posting publicly, or modifying and redistributing this skill under another name.
- The official version is distributed only by the author or through the 1C Vietnam organization. If you received this skill from another source, check the version number at the top of this file.

### Accuracy

Content was checked against the source materials and source code at release time. Statements outside the course are marked "(ngoài giáo trình — hãy kiểm tra lại trong Syntax assistant)" ("outside the course — verify in the Syntax assistant"). Always run code on the platform before relying on it.

### Contact

Feedback, bug reports and permission requests: Phạm Viết Quý — quypv@1c.com.vn

---

## Tiếng Việt

### Quyền sở hữu nội dung

- **Skill này** (cấu trúc, hướng dẫn trong `SKILL.md`, bảng thuật ngữ, ghi chú bài học, toàn bộ phần giải thích và tổng hợp bằng tiếng Việt) do Phạm Viết Quý biên soạn cho các chương trình đào tạo phát triển trên nền tảng 1C:Enterprise của 1C Vietnam.
- **Nội dung giáo trình** (tóm tắt 24 bài Theory/Practice và bài Extensions trong `references/lessons/`) dựa trên tài liệu đào tạo của 1C. Bản quyền tài liệu gốc thuộc về 1C.
- **Code demo của khóa học** trong `references/lessons/` được trích từ cấu hình dùng để quay bài giảng (repo `1CJDCourse`, các nhánh `lesson/NN-theory`), dùng cho mục đích giảng dạy.
- **Code extension** của bài Extensions được trích từ các file `.cfe` của giảng viên (chỉ demo lý thuyết) (repo `1CJDCourse`, các nhánh `lesson/extensions-*`).
- **Code ERP_Practice** trong `references/erp-practice/` được trích từ repo `vuongviet2x/ERP_Practice` (commit `de6ec9d`) — cấu hình làm theo sách *1C:Enterprise 8.3 Practical Developer's Guide*, dùng cho giảng dạy với sự đồng ý của giảng viên.
- **Bảng video khóa Junior** trong `references/video-junior-course.md` nối 49 video của playlist YouTube "Junior Developer Course" (1C Vietnam Academy) với các bài của giáo trình, dựa trên bảng ánh xạ của giảng viên (mã video đọc lại từ playlist ngày 07/10/2026).
- **Bảng video giải đáp và video thực hành** trong `references/video-qa-thuc-chien.md` và `references/video-thuc-hanh.md` nối 48 video của ba playlist YouTube của Trung tâm đào tạo lập trình 1C Việt Nam ("Giải đáp câu hỏi…", "Tuyển tập các bài tập thực hành…" phần 1–2) với triệu chứng, bài giáo trình, lộ trình người học và đề BTL Jet. Nội dung video được kiểm chứng bằng transcript tự động ngày 07/10/2026; lộ trình theo khuyến nghị của giảng viên.
- **Bản dành cho sinh viên:** bản này không chứa lời giải các bài thực hành (Practice) của giáo trình, chỉ có thẻ gợi ý; trợ lý được hướng dẫn để gợi ý chứ không giải hộ. Lời giải chính thức do giảng viên nắm giữ.
- **Code của 1C:Jet** trong `references/jet/` được trích nguyên văn từ dự án mã nguồn mở 1C:Jet (github.com/1Ci-Company/Jet, nhánh `community`, commit `80884de`), Copyright (c) 2025 1Ci (1C International), phát hành theo giấy phép MIT. Toàn văn giấy phép (bản tiếng Anh có hiệu lực pháp lý): `LICENSE-Jet-MIT.txt`. Giấy phép MIT chỉ áp dụng cho phần code Jet được trích, không áp dụng cho phần còn lại của skill.
- **Chuẩn phát triển** trong `references/code-review/chuan-phat-trien.md` là bản tóm tắt tiếng Việt của tác giả từ bộ chuẩn phát triển của 1C, qua bản biên tập mở v8std.ru (github.com/zeegin/v8std, CC0 1.0). Bản quyền chuẩn gốc thuộc 1C.
- **Tên và chữ ký API của SSL** trong `references/code-review/ssl-api-en.md` lấy từ Standard Subsystems Library 3.1 World edition (bản mirror github.com/1c-syntax/ssl_3_1_eng, ghi giấy phép CC BY 4.0). SSL là sản phẩm của 1C; skill chỉ trích tên và chữ ký hàm.
- **Tên quy tắc phân tích tĩnh** trong `references/code-review/` lấy từ BSL Language Server (LGPL-3.0) và 1C:Code style V8 (EPL-2.0); chỉ dẫn tên, không chứa code của các dự án này.
- **Danh mục nguồn bên ngoài** trong `references/code-review/nguon-ngoai.md` chỉ dẫn link; code của các repo đó không có trong skill.
- **Tư liệu tình huống doanh nghiệp** trong `references/erp-cases/` được rút từ mẫu khảo sát và tài liệu giải pháp nội bộ của 1C Vietnam. Mọi tên khách hàng, số liệu và chi tiết nhận diện đã được bỏ và thay bằng bí danh; skill không chứa file gốc nào của khách hàng.

### Tóm tắt giấy phép MIT của Jet (tham khảo, không thay thế bản gốc)

Bất kỳ ai cũng được dùng, sao chép, sửa đổi, gộp, xuất bản, phân phối, cấp phép lại và bán bản sao của phần mềm, miễn phí, với điều kiện giữ nguyên thông báo bản quyền và nội dung giấy phép trong mọi bản sao hoặc phần đáng kể của phần mềm. Phần mềm được cung cấp "nguyên trạng", không kèm bất kỳ bảo đảm nào; tác giả không chịu trách nhiệm về thiệt hại phát sinh.

### Phạm vi sử dụng

- **Được phép:** sinh viên, học viên và Intern Dev trong các chương trình đào tạo của 1C Vietnam sử dụng skill này để học tập và làm đồ án.
- **Không được phép khi chưa có đồng ý bằng văn bản của 1C Vietnam:** phát hành lại, bán, đăng công khai, hoặc chỉnh sửa rồi phân phối dưới tên khác.
- Bản chính thức chỉ được phát hành bởi tác giả hoặc qua tổ chức 1C Vietnam. Nếu bạn nhận skill từ nguồn khác, hãy đối chiếu số phiên bản ở đầu file này.

### Lưu ý về độ chính xác

Nội dung được đối chiếu với tài liệu gốc và mã nguồn tại thời điểm phát hành. Các phần ngoài giáo trình được đánh dấu "(ngoài giáo trình — hãy kiểm tra lại trong Syntax assistant)". Luôn chạy thử code trên platform trước khi dùng.

### Liên hệ

Góp ý, báo lỗi và xin phép sử dụng ngoài phạm vi: Phạm Viết Quý — quypv@1c.com.vn
